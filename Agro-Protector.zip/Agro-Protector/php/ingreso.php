<?php
// Recibir los parámetros mediante GET enviada desde la app Android
$nombre   = $_GET["nombre"];
$apellido = $_GET["apellido"];
$password = $_GET["password"];
$rol      = $_GET["rol"];

// Incluir la conexión a la base de datos
include("cn.php");

// Insertar en la tabla usuarios con la nueva estructura
// Nota: 'id' es AUTO_INCREMENT en MySQL, por lo que se envía NULL sin comillas
$q = mysqli_query($c, "INSERT INTO usuarios (id, nombre, apellido, password, rol) VALUES (NULL, '$nombre', '$apellido', '$password', '$rol')");

if ($q) {
    echo "Registro insertado exitoso";
} else {
    echo "Fallo en el registro";
}
?>